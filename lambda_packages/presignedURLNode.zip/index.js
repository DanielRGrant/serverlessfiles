'use strict';

const AWS = require('aws-sdk');
const s3 = new AWS.S3({signatureVersion: 'v4'});

exports.handler = (event, context, callback) => {
  const bucket = 'retrobase-data';
  if (!bucket) {
    callback(new Error(`S3 bucket not set`));
  }
  
  //Get metadataN
 // const tmpMetadata = JSON.stringify(event["queryStringParameters"])
  //const metadata = {"x-amz-meta-data": "poo"}
  console.log(event["queryStringParameters"])
  const rand = Math.floor(Math.random() * 100000000000000)
  const key = rand + ".txt";
  if (!key) {
    callback(new Error('S3 object key missing'));
    return;
  }

  const params = {
      'Bucket': bucket, 
      'Key': key,
      'Metadata': event['queryStringParameters']
  };

  s3.getSignedUrl('putObject', params, (error, url) => {
    if (error) {
      callback(error);
    } else {
        const response = {
            statusCode: 200,
            headers: {
                "Access-Control-Allow-Headers": "Content-Type",
                "Access-Control-Allow-Origin": "*",
                "Access-Control-Allow-Methods": "OPTIONS,POST,GET"
            },
            body: JSON.stringify(
                {"url": url,
                "key": key
            }),
        };
        callback(null, response);
    }
  });
};

