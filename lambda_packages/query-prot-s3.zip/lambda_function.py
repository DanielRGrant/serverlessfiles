import boto3
import json
import boto3
import time
from boto3.dynamodb.conditions import Key
import logging
import sys
import json
import traceback

logger = logging.getLogger()
logger.setLevel(logging.INFO)

bucket = 'query-sequences'
key = 'all-prot-sequences.parquet'


s3_client = boto3.client('s3')

def lambda_handler(event, context):
    try:
        start = time.time()    

        logger.info(f'Event: {event}')

        seq = event["query"]

        logger.info(f'Beginning querying sequence...')

        matches = []

        resp = s3_client.select_object_content(
            Bucket=bucket,
            Key=key,
            ExpressionType='SQL',
            Expression="SELECT * FROM S3object s where s.\"prot_seq\" LIKE {}{}{}".format("'%", seq, "%'"),
            InputSerialization={'Parquet': {}},
            OutputSerialization = {'JSON': {}},
        )

    # extract data from response            
        items = []
        for event in resp['Payload']:
            if 'Records' in event:
                records = event['Records']['Payload'].decode('utf-8')
                records = records.split("\n")
    
                for record in records:
                    try:
                        item = json.loads(record)
                        item["dna_id"]
                        items.append(item)
                    except:
                        pass
                    items.append(item)
        
        statusCode = 200
        logging.info(f'Finished with statusCode: {statusCode}')
        
        return {
            "statusCode": statusCode,
            "body": items
        }
        
    except Exception as error:
        exception_type, exception_value, exception_traceback = sys.exc_info()
        traceback_string = traceback.format_exception(exception_type, exception_value, exception_traceback)
        err_msg = json.dumps({
            "errorType": exception_type.__name__,
            "errorMessage": str(exception_value),
            "stackTrace": traceback_string
        })
        logger.error(err_msg)

