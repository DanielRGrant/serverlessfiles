import json
import boto3
from boto3.dynamodb.conditions import Key
import logging
import traceback
import sys

logger = logging.getLogger()
logger.setLevel(logging.INFO)


dynamodb = boto3.resource("dynamodb")
class_db = dynamodb.Table("class_db")

def lambda_handler(event, context):
    try:
        logger.info(f'Event: {event}')
        rtclass = event["class"]
        
        response = class_db.query(
            KeyConditionExpression=Key("class").eq(rtclass)    
        )
    
        try:
            body = response["Items"][0]
            statusCode = 200
        except:
            body = "InvalidKeyError"
            statusCode = 204
        
        logger.info(f'Finished with statusCode: {statusCode}')
        
        return {
            'statusCode': statusCode,
            'body': body
        }
    except Exception as error:
        exception_type, exception_value, exception_traceback = sys.exc_info()
        traceback_string = traceback.format_exception(exception_type, exception_value, exception_traceback)
        err_msg = json.dumps({
            "errorType": exception_type.__name__,
            "errorMessage": str(exception_value),
            "stackTrace": traceback_string
        })
        logger.error(err_msg)