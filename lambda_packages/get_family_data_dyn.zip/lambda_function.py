import json
import boto3
from boto3.dynamodb.conditions import Key
import sys
import traceback
import logging

logger = logging.getLogger()
logger.setLevel(logging.INFO)


dynamodb = boto3.resource("dynamodb")
query_db = dynamodb.Table("query_db")

def lambda_handler(event, context):
    try:
        logger.info(f'Event: {event}')

        family = event["family"]
        
        response = query_db.query(
            IndexName="family-index",
            KeyConditionExpression=Key('family').eq(family)
        )
    
    
        if response["Items"]:
            body = response["Items"]
            statusCode=200
        else:
            body="InvalidKeyError"
            statusCode=204
            
            logger.info(f'Finished with status code: {statusCode}')
        
        return {
            "statusCode": statusCode,
            "body": body
        }
    except Exception as error:
        exception_type, exception_value, exception_traceback = sys.exc_info()
        traceback_string = traceback.format_exception(exception_type, exception_value, exception_traceback)
        err_msg = json.dumps({
            "errorType": exception_type.__name__,
            "errorMessage": str(exception_value),
            "stackTrace": traceback_string
        })
        logger.error(err_msg)
    