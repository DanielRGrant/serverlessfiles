import json
import boto3
from boto3.dynamodb.conditions import Key


dynamodb = boto3.resource('dynamodb')
query_db = dynamodb.Table('query_db')
class_db = dynamodb.Table('class_db')

def lambda_handler(event, context):
    print(event)
    rtClass = event["class"]
    response = query_db.query(
        IndexName="class-index",
        KeyConditionExpression=Key('class').eq(rtClass)
    )

    items = response["Items"]
    
    families = []
    proteins = []
    for item in items:
        if not item["family"] in families:
            families.append(item["family"])
        
        if item["prot_id"] == "null":
            continue
        
        protein = item["protein"].split("#")
        for prot in protein:
            if not prot in proteins:            
                proteins.append(prot)
                
    families = sorted(families, key=lambda item: (int(item.partition(' ')[0])
                               if item[0].isdigit() else float('inf'), item))
    proteins = sorted(proteins, key=lambda item: (int(item.partition(' ')[0])
                               if item[0].isdigit() else float('inf'), item))
                               
    families = "#".join(families)
    proteins = "#".join(proteins)
    
    item = {
            "class": rtClass,
            "proteins": proteins,
            "families": families
        }
    print("Putting item to class_db: ", item)
    class_db.put_item(
        Item=item
    )
    
    return {
        'statusCode': 200,
        'body': "complete"
    }
